import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/farm_models.dart';
import '../providers/farm_provider.dart';

class CowManagementScreen extends StatefulWidget {
  const CowManagementScreen({super.key});

  @override
  State<CowManagementScreen> createState() => _CowManagementScreenState();
}

class _CowManagementScreenState extends State<CowManagementScreen> {
  String searchKey = '';

  @override
  Widget build(BuildContext context) {
    final farm = Provider.of<FarmProvider>(context);
    final filteredCows = farm.cows
        .where((c) => c.name.contains(searchKey) || c.tagNo.contains(searchKey) || c.breed.contains(searchKey))
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('૧. ગાયની માહિતી')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'ગાયનું નામ કે ટેગ નંબર શોધો...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                filled: true,
                fillColor: Colors.white,
              ),
              onChanged: (val) => setState(() => searchKey = val),
            ),
          ),
          Expanded(
            child: filteredCows.isEmpty
                ? const Center(child: Text('કોઈ પશુ મળી આવ્યા નથી.'))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    itemCount: filteredCows.length,
                    itemBuilder: (context, index) {
                      final cow = filteredCows[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          leading: const CircleAvatar(
                            backgroundColor: Color(0xFFE8F5E9),
                            child: Icon(Icons.pets, color: Color(0xFF1B5E20)),
                          ),
                          title: Text('${cow.name} (${cow.tagNo})', style: const TextStyle(fontWeight: FontWeight.bold)),
                          subtitle: Text('ઓલાદ: ${cow.breed} | દૂધ: ${cow.dailyAvgMilk} L/દિન'),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit, color: Colors.blue),
                                onPressed: () => _showCowDialog(context, farm, cow),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete, color: Colors.red),
                                onPressed: () => farm.deleteCow(cow),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCowDialog(context, farm, null),
        icon: const Icon(Icons.add),
        label: const Text('નવી ગાય ઉમેરો'),
      ),
    );
  }

  void _showCowDialog(BuildContext context, FarmProvider farm, Cow? editCow) {
    final tagCtrl = TextEditingController(text: editCow?.tagNo ?? 'IN-${101 + farm.cows.length}');
    final nameCtrl = TextEditingController(text: editCow?.name ?? '');
    final breedCtrl = TextEditingController(text: editCow?.breed ?? 'ગીર');
    final milkCtrl = TextEditingController(text: editCow?.dailyAvgMilk.toString() ?? '10.0');

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(editCow == null ? 'નવી ગાય ઉમેરો' : 'ગાયની વિગત સુધારો'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: tagCtrl, decoration: const InputDecoration(labelText: 'ટેગ નંબર (Tag No)')),
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'ગાયનું નામ')),
              TextField(controller: breedCtrl, decoration: const InputDecoration(labelText: 'ઓલાદ (Breed)')),
              TextField(controller: milkCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'દૈનિક સરેરાશ દૂધ (L)')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('રદ કરો')),
          ElevatedButton(
            onPressed: () {
              if (editCow == null) {
                farm.addCow(Cow(
                  id: DateTime.now().millisecondsSinceEpoch.toString(),
                  tagNo: tagCtrl.text,
                  name: nameCtrl.text,
                  breed: breedCtrl.text,
                  ageYears: 3.5,
                  status: 'દૂધ આપતી (Milking)',
                  dailyAvgMilk: double.tryParse(milkCtrl.text) ?? 10.0,
                ));
              } else {
                editCow.tagNo = tagCtrl.text;
                editCow.name = nameCtrl.text;
                editCow.breed = breedCtrl.text;
                editCow.dailyAvgMilk = double.tryParse(milkCtrl.text) ?? 10.0;
                farm.updateCow(editCow);
              }
              Navigator.pop(context);
            },
            child: const Text('સાચવો'),
          )
        ],
      ),
    );
  }
}
