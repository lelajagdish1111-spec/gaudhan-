import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/farm_provider.dart';

class IncomeLedgerScreen extends StatelessWidget {
  const IncomeLedgerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final farm = Provider.of<FarmProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('૬. આવક અને નફો')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: farm.incomes.length,
        itemBuilder: (context, index) {
          final i = farm.incomes[index];
          return Card(
            child: ListTile(
              leading: const Icon(Icons.monetization_on, color: Color(0xFF2E7D32)),
              title: Text(i.title),
              subtitle: Text('${i.category} | ${i.date}'),
              trailing: Text('+ ₹ ${i.amount}', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2E7D32))),
            ),
          );
        },
      ),
    );
  }
}
