import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/farm_provider.dart';

class BreedingCalvingScreen extends StatelessWidget {
  const BreedingCalvingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final farm = Provider.of<FarmProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('૪. ગર્ભાધાન અને વાછરડું')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: farm.breedingRecords.length,
        itemBuilder: (context, index) {
          final b = farm.breedingRecords[index];
          return Card(
            child: ListTile(
              leading: const Icon(Icons.favorite, color: Colors.orange),
              title: Text('${b.cowName} - સીમેન: ${b.bullSemenTag}'),
              subtitle: Text('AI તારીખ: ${b.aiDate} | અપેક્ષિત વિયાણ: ${b.expectedCalvingDate}'),
              trailing: Chip(label: Text(b.status, style: const TextStyle(fontSize: 10))),
            ),
          );
        },
      ),
    );
  }
}
