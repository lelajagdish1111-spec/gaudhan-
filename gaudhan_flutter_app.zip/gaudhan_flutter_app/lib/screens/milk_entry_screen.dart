import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

import '../models/farm_models.dart';
import '../providers/farm_provider.dart';

class MilkEntryScreen extends StatelessWidget {
  const MilkEntryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final farm = Provider.of<FarmProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('૨. દૂધ ઉત્પાદન એન્ટ્રી')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              color: const Color(0xFFE8F5E9),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(children: [
                      const Text('આજનું દૂધ'),
                      Text('${farm.todayMilkTotal.toStringAsFixed(1)} L', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1B5E20))),
                    ]),
                    Column(children: [
                      const Text('સરેરાશ FAT'),
                      Text('${farm.avgFatToday.toStringAsFixed(1)} %', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF1B5E20))),
                    ]),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            const Align(
              alignment: Alignment.centerLeft,
              child: Text('તાજેતરની દૂધ એન્ટ્રીઝ', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            const SizedBox(height: 8),

            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: farm.milkRecords.length,
              itemBuilder: (context, index) {
                final r = farm.milkRecords[index];
                return Card(
                  child: ListTile(
                    title: Text('${r.cowName} - ${r.totalLiters} લીટર (FAT: ${r.fat}%)'),
                    subtitle: Text('તારીખ: ${r.date} | સવાર: ${r.morningLiters}L, સાંજ: ${r.eveningLiters}L'),
                    trailing: Text('₹ ${r.totalRevenue.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2E7D32))),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddMilkDialog(context, farm),
        icon: const Icon(Icons.add),
        label: const Text('નવું દૂધ ઉમેરો'),
      ),
    );
  }

  void _showAddMilkDialog(BuildContext context, FarmProvider farm) {
    if (farm.cows.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('કૃપા કરીને પહેલા ગાય ઉમેરો.')));
      return;
    }

    String selectedCowId = farm.cows.first.id;
    String selectedCowName = farm.cows.first.name;
    final morningCtrl = TextEditingController(text: '7.5');
    final eveningCtrl = TextEditingController(text: '6.5');
    final fatCtrl = TextEditingController(text: '6.5');
    final rateCtrl = TextEditingController(text: farm.settings.defaultMilkRate.toString());

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('દૂધ એન્ટ્રી ઉમેરો'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: selectedCowId,
                items: farm.cows.map((c) => DropdownMenuItem(value: c.id, child: Text('${c.name} (${c.tagNo})'))).toList(),
                onChanged: (val) {
                  selectedCowId = val!;
                  selectedCowName = farm.cows.firstWhere((c) => c.id == val).name;
                },
                decoration: const InputDecoration(labelText: 'ગાય પસંદ કરો'),
              ),
              TextField(controller: morningCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'સવાર દૂધ (L)')),
              TextField(controller: eveningCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'સાંજ દૂધ (L)')),
              TextField(controller: fatCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'FAT %')),
              TextField(controller: rateCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ભાવ પ્રતિ લીટર (₹)')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('રદ કરો')),
          ElevatedButton(
            onPressed: () {
              final m = double.tryParse(morningCtrl.text) ?? 0;
              final e = double.tryParse(eveningCtrl.text) ?? 0;
              final total = m + e;
              final rate = double.tryParse(rateCtrl.text) ?? 65.0;

              farm.addMilkRecord(MilkRecord(
                id: DateTime.now().millisecondsSinceEpoch.toString(),
                cowId: selectedCowId,
                cowName: selectedCowName,
                date: DateFormat('yyyy-MM-DD').format(DateTime.now()),
                morningLiters: m,
                eveningLiters: e,
                totalLiters: total,
                fat: double.tryParse(fatCtrl.text) ?? 6.0,
                snf: 9.0,
                ratePerLiter: rate,
                totalRevenue: total * rate,
              ));
              Navigator.pop(context);
            },
            child: const Text('સાચવો'),
          )
        ],
      ),
    );
  }
}
