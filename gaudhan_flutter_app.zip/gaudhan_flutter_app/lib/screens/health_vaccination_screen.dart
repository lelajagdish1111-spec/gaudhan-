import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/farm_provider.dart';

class HealthVaccinationScreen extends StatelessWidget {
  const HealthVaccinationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final farm = Provider.of<FarmProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('૩. આરોગ્ય અને રસીકરણ')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: farm.healthRecords.length,
        itemBuilder: (context, index) {
          final h = farm.healthRecords[index];
          return Card(
            child: ListTile(
              leading: const Icon(Icons.medical_services, color: Color(0xFF1B5E20)),
              title: Text('${h.title} (${h.cowName})'),
              subtitle: Text('પ્રકાર: ${h.type} | ડૉક્ટર: ${h.doctorName ?? 'N/A'}'),
              trailing: Text('₹ ${h.cost}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)),
            ),
          );
        },
      ),
    );
  }
}
