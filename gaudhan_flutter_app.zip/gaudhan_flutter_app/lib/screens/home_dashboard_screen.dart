import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/farm_provider.dart';
import 'cow_management_screen.dart';
import 'milk_entry_screen.dart';
import 'health_vaccination_screen.dart';
import 'breeding_calving_screen.dart';
import 'expense_ledger_screen.dart';
import 'income_ledger_screen.dart';
import 'settings_backup_screen.dart';

class HomeDashboardScreen extends StatelessWidget {
  const HomeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final farm = Provider.of<FarmProvider>(context);

    final List<Map<String, dynamic>> menuItems = [
      {
        'title': '૧. ગાયની માહિતી',
        'subtitle': '${farm.cows.length} પશુઓની નોંધણી',
        'icon': Icons.pets_rounded,
        'color': const Color(0xFF1B5E20),
        'screen': const CowManagementScreen(),
      },
      {
        'title': '૨. દૂધ ઉત્પાદન',
        'subtitle': 'આજ: ${farm.todayMilkTotal.toStringAsFixed(1)} L | FAT ${farm.avgFatToday.toStringAsFixed(1)}%',
        'icon': Icons.water_drop_rounded,
        'color': const Color(0xFF2E7D32),
        'screen': const MilkEntryScreen(),
      },
      {
        'title': '૩. આરોગ્ય અને રસીકરણ',
        'subtitle': '${farm.healthRecords.length} રસી/ઇલાજ નોંધ',
        'icon': Icons.health_and_safety_rounded,
        'color': const Color(0xFF388E3C),
        'screen': const HealthVaccinationScreen(),
      },
      {
        'title': '૪. ગર્ભાધાન અને વાછરડું',
        'subtitle': '${farm.breedingRecords.length} બીજદાન એન્ટ્રી',
        'icon': Icons.favorite_rounded,
        'color': const Color(0xFFE65100),
        'screen': const BreedingCalvingScreen(),
      },
      {
        'title': '૫. ખર્ચ નોંધ',
        'subtitle': 'કુલ ખર્ચ: ₹ ${farm.totalExpenseSum.toStringAsFixed(0)}',
        'icon': Icons.account_balance_wallet_rounded,
        'color': const Color(0xFFC62828),
        'screen': const ExpenseLedgerScreen(),
      },
      {
        'title': '૬. આવક અને નફો',
        'subtitle': 'ચોખ્ખો નફો: ₹ ${farm.netProfit.toStringAsFixed(0)}',
        'icon': Icons.monetization_on_rounded,
        'color': const Color(0xFF2E7D32),
        'screen': const IncomeLedgerScreen(),
      },
      {
        'title': '૭. સેટિંગ્સ & બેકઅપ',
        'subtitle': 'JSON ડાઉનલોડ & રીસ્ટોર',
        'icon': Icons.settings_rounded,
        'color': const Color(0xFF455A64),
        'screen': const SettingsBackupScreen(),
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.agriculture_rounded, size: 26),
            const SizedBox(width: 8),
            Text(farm.settings.farmName),
          ],
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Banner Summary Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF1B5E20), Color(0xFF2E7D32)],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8)],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'માલિક: ${farm.settings.ownerName}',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Text('ઓફલાઇન વર્ઝન', style: TextStyle(color: Colors.white, fontSize: 11)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _metricBox('કુલ પશુ', '${farm.cows.length}', Icons.pets),
                        _metricBox('આજનું દૂધ', '${farm.todayMilkTotal.toStringAsFixed(1)} L', Icons.water_drop),
                        _metricBox('ચોખ્ખો નફો', '₹ ${farm.netProfit.toStringAsFixed(0)}', Icons.trending_up),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              const Text(
                'મુખ્ય વિભાગો (Main Menu)',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF1B5E20)),
              ),
              const SizedBox(height: 12),

              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: menuItems.length,
                itemBuilder: (context, index) {
                  final item = menuItems[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      leading: CircleAvatar(
                        backgroundColor: (item['color'] as Color).withOpacity(0.12),
                        child: Icon(item['icon'] as IconData, color: item['color'] as Color),
                      ),
                      title: Text(
                        item['title'] as String,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                      ),
                      subtitle: Text(item['subtitle'] as String, style: const TextStyle(fontSize: 12)),
                      trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: Colors.grey),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => item['screen']),
                        );
                      },
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _metricBox(String label, String val, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: Colors.white70, size: 20),
        const SizedBox(height: 4),
        Text(val, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
      ],
    );
  }
}
