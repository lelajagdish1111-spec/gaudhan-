import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/farm_provider.dart';

class ExpenseLedgerScreen extends StatelessWidget {
  const ExpenseLedgerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final farm = Provider.of<FarmProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('૫. ખર્ચ નોંધ')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: farm.expenses.length,
        itemBuilder: (context, index) {
          final e = farm.expenses[index];
          return Card(
            child: ListTile(
              leading: const Icon(Icons.shopping_bag, color: Colors.red),
              title: Text(e.title),
              subtitle: Text('${e.category} | ${e.date}'),
              trailing: Text('₹ ${e.amount}', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)),
            ),
          );
        },
      ),
    );
  }
}
