import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/farm_provider.dart';

class SettingsBackupScreen extends StatelessWidget {
  const SettingsBackupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final farm = Provider.of<FarmProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('૭. સેટિંગ્સ & બેકઅપ')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: const Text('ફાર્મનું નામ'),
              subtitle: Text(farm.settings.farmName),
              trailing: const Icon(Icons.store),
            ),
          ),
          Card(
            child: ListTile(
              title: const Text('માલિકનું નામ'),
              subtitle: Text(farm.settings.ownerName),
              trailing: const Icon(Icons.person),
            ),
          ),
          Card(
            child: ListTile(
              title: const Text('મોબાઇલ નંબર'),
              subtitle: Text(farm.settings.phone),
              trailing: const Icon(Icons.phone),
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1B5E20), foregroundColor: Colors.white, padding: const EdgeInsets.all(16)),
            onPressed: () {
              final jsonBackup = farm.exportBackupJson();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('JSON બેકઅપ ડેટા સફળતાપૂર્વક નિકાસ થયો!')),
              );
            },
            icon: const Icon(Icons.download),
            label: const Text('JSON ડેટા બેકઅપ ડાઉનલોડ કરો'),
          ),
        ],
      ),
    );
  }
}
