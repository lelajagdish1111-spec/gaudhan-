import 'package:hive/hive.dart';

part 'farm_models.g.dart';

@HiveType(typeId: 0)
class Cow extends HiveObject {
  @HiveField(0) final String id;
  @HiveField(1) String tagNo;
  @HiveField(2) String name;
  @HiveField(3) String breed;
  @HiveField(4) double ageYears;
  @HiveField(5) String status;
  @HiveField(6) double dailyAvgMilk;
  @HiveField(7) String? lastCalvingDate;
  @HiveField(8) String? expectedCalvingDate;
  @HiveField(9) String? notes;

  Cow({
    required this.id,
    required this.tagNo,
    required this.name,
    required this.breed,
    required this.ageYears,
    required this.status,
    required this.dailyAvgMilk,
    this.lastCalvingDate,
    this.expectedCalvingDate,
    this.notes,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'tagNo': tagNo,
    'name': name,
    'breed': breed,
    'ageYears': ageYears,
    'status': status,
    'dailyAvgMilk': dailyAvgMilk,
    'lastCalvingDate': lastCalvingDate,
    'expectedCalvingDate': expectedCalvingDate,
    'notes': notes,
  };

  factory Cow.fromJson(Map<String, dynamic> json) => Cow(
    id: json['id'],
    tagNo: json['tagNo'],
    name: json['name'],
    breed: json['breed'],
    ageYears: (json['ageYears'] as num).toDouble(),
    status: json['status'],
    dailyAvgMilk: (json['dailyAvgMilk'] as num).toDouble(),
    lastCalvingDate: json['lastCalvingDate'],
    expectedCalvingDate: json['expectedCalvingDate'],
    notes: json['notes'],
  );
}

@HiveType(typeId: 1)
class MilkRecord extends HiveObject {
  @HiveField(0) final String id;
  @HiveField(1) String cowId;
  @HiveField(2) String cowName;
  @HiveField(3) String date;
  @HiveField(4) double morningLiters;
  @HiveField(5) double eveningLiters;
  @HiveField(6) double totalLiters;
  @HiveField(7) double fat;
  @HiveField(8) double snf;
  @HiveField(9) double ratePerLiter;
  @HiveField(10) double totalRevenue;

  MilkRecord({
    required this.id,
    required this.cowId,
    required this.cowName,
    required this.date,
    required this.morningLiters,
    required this.eveningLiters,
    required this.totalLiters,
    required this.fat,
    required this.snf,
    required this.ratePerLiter,
    required this.totalRevenue,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'cowId': cowId,
    'cowName': cowName,
    'date': date,
    'morningLiters': morningLiters,
    'eveningLiters': eveningLiters,
    'totalLiters': totalLiters,
    'fat': fat,
    'snf': snf,
    'ratePerLiter': ratePerLiter,
    'totalRevenue': totalRevenue,
  };

  factory MilkRecord.fromJson(Map<String, dynamic> json) => MilkRecord(
    id: json['id'],
    cowId: json['cowId'],
    cowName: json['cowName'],
    date: json['date'],
    morningLiters: (json['morningLiters'] as num).toDouble(),
    eveningLiters: (json['eveningLiters'] as num).toDouble(),
    totalLiters: (json['totalLiters'] as num).toDouble(),
    fat: (json['fat'] as num).toDouble(),
    snf: (json['snf'] as num).toDouble(),
    ratePerLiter: (json['ratePerLiter'] as num).toDouble(),
    totalRevenue: (json['totalRevenue'] as num).toDouble(),
  );
}

@HiveType(typeId: 2)
class HealthRecord extends HiveObject {
  @HiveField(0) final String id;
  @HiveField(1) String cowId;
  @HiveField(2) String cowName;
  @HiveField(3) String date;
  @HiveField(4) String type;
  @HiveField(5) String title;
  @HiveField(6) String? doctorName;
  @HiveField(7) double cost;
  @HiveField(8) String? nextDueDate;
  @HiveField(9) String? notes;

  HealthRecord({
    required this.id,
    required this.cowId,
    required this.cowName,
    required this.date,
    required this.type,
    required this.title,
    this.doctorName,
    required this.cost,
    this.nextDueDate,
    this.notes,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'cowId': cowId,
    'cowName': cowName,
    'date': date,
    'type': type,
    'title': title,
    'doctorName': doctorName,
    'cost': cost,
    'nextDueDate': nextDueDate,
    'notes': notes,
  };

  factory HealthRecord.fromJson(Map<String, dynamic> json) => HealthRecord(
    id: json['id'],
    cowId: json['cowId'],
    cowName: json['cowName'],
    date: json['date'],
    type: json['type'],
    title: json['title'],
    doctorName: json['doctorName'],
    cost: (json['cost'] as num).toDouble(),
    nextDueDate: json['nextDueDate'],
    notes: json['notes'],
  );
}

@HiveType(typeId: 3)
class BreedingRecord extends HiveObject {
  @HiveField(0) final String id;
  @HiveField(1) String cowId;
  @HiveField(2) String cowName;
  @HiveField(3) String aiDate;
  @HiveField(4) String bullSemenTag;
  @HiveField(5) String? technicianName;
  @HiveField(6) String? pregnancyCheckDate;
  @HiveField(7) String expectedCalvingDate;
  @HiveField(8) String status;
  @HiveField(9) String? notes;

  BreedingRecord({
    required this.id,
    required this.cowId,
    required this.cowName,
    required this.aiDate,
    required this.bullSemenTag,
    this.technicianName,
    this.pregnancyCheckDate,
    required this.expectedCalvingDate,
    required this.status,
    this.notes,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'cowId': cowId,
    'cowName': cowName,
    'aiDate': aiDate,
    'bullSemenTag': bullSemenTag,
    'technicianName': technicianName,
    'pregnancyCheckDate': pregnancyCheckDate,
    'expectedCalvingDate': expectedCalvingDate,
    'status': status,
    'notes': notes,
  };

  factory BreedingRecord.fromJson(Map<String, dynamic> json) => BreedingRecord(
    id: json['id'],
    cowId: json['cowId'],
    cowName: json['cowName'],
    aiDate: json['aiDate'],
    bullSemenTag: json['bullSemenTag'],
    technicianName: json['technicianName'],
    pregnancyCheckDate: json['pregnancyCheckDate'],
    expectedCalvingDate: json['expectedCalvingDate'],
    status: json['status'],
    notes: json['notes'],
  );
}

@HiveType(typeId: 4)
class ExpenseRecord extends HiveObject {
  @HiveField(0) final String id;
  @HiveField(1) String date;
  @HiveField(2) String category;
  @HiveField(3) String title;
  @HiveField(4) double amount;
  @HiveField(5) String? notes;

  ExpenseRecord({
    required this.id,
    required this.date,
    required this.category,
    required this.title,
    required this.amount,
    this.notes,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'date': date,
    'category': category,
    'title': title,
    'amount': amount,
    'notes': notes,
  };

  factory ExpenseRecord.fromJson(Map<String, dynamic> json) => ExpenseRecord(
    id: json['id'],
    date: json['date'],
    category: json['category'],
    title: json['title'],
    amount: (json['amount'] as num).toDouble(),
    notes: json['notes'],
  );
}

@HiveType(typeId: 5)
class IncomeRecord extends HiveObject {
  @HiveField(0) final String id;
  @HiveField(1) String date;
  @HiveField(2) String category;
  @HiveField(3) String title;
  @HiveField(4) double amount;
  @HiveField(5) String? customerName;
  @HiveField(6) String? notes;

  IncomeRecord({
    required this.id,
    required this.date,
    required this.category,
    required this.title,
    required this.amount,
    this.customerName,
    this.notes,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'date': date,
    'category': category,
    'title': title,
    'amount': amount,
    'customerName': customerName,
    'notes': notes,
  };

  factory IncomeRecord.fromJson(Map<String, dynamic> json) => IncomeRecord(
    id: json['id'],
    date: json['date'],
    category: json['category'],
    title: json['title'],
    amount: (json['amount'] as num).toDouble(),
    customerName: json['customerName'],
    notes: json['notes'],
  );
}

@HiveType(typeId: 6)
class FarmSettings extends HiveObject {
  @HiveField(0) String farmName;
  @HiveField(1) String ownerName;
  @HiveField(2) String village;
  @HiveField(3) String phone;
  @HiveField(4) double defaultMilkRate;

  FarmSettings({
    required this.farmName,
    required this.ownerName,
    required this.village,
    required this.phone,
    required this.defaultMilkRate,
  });

  Map<String, dynamic> toJson() => {
    'farmName': farmName,
    'ownerName': ownerName,
    'village': village,
    'phone': phone,
    'defaultMilkRate': defaultMilkRate,
  };

  factory FarmSettings.fromJson(Map<String, dynamic> json) => FarmSettings(
    farmName: json['farmName'],
    ownerName: json['ownerName'],
    village: json['village'],
    phone: json['phone'],
    defaultMilkRate: (json['defaultMilkRate'] as num).toDouble(),
  );
}
