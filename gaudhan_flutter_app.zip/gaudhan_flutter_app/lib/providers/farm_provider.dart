import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';

import '../models/farm_models.dart';

class FarmProvider extends ChangeNotifier {
  late Box<Cow> _cowsBox;
  late Box<MilkRecord> _milkBox;
  late Box<HealthRecord> _healthBox;
  late Box<BreedingRecord> _breedingBox;
  late Box<ExpenseRecord> _expenseBox;
  late Box<IncomeRecord> _incomeBox;
  late Box<FarmSettings> _settingsBox;

  List<Cow> cows = [];
  List<MilkRecord> milkRecords = [];
  List<HealthRecord> healthRecords = [];
  List<BreedingRecord> breedingRecords = [];
  List<ExpenseRecord> expenses = [];
  List<IncomeRecord> incomes = [];
  FarmSettings settings = FarmSettings(
    farmName: 'જય ગૌમાતા ડેરી ફાર્મ',
    ownerName: 'રમેશભાઈ પટેલ',
    village: 'આણંદ, ગુજરાત',
    phone: '9876543210',
    defaultMilkRate: 65.0,
  );

  void initData() {
    _cowsBox = Hive.box<Cow>('cows_box');
    _milkBox = Hive.box<MilkRecord>('milk_box');
    _healthBox = Hive.box<HealthRecord>('health_box');
    _breedingBox = Hive.box<BreedingRecord>('breeding_box');
    _expenseBox = Hive.box<ExpenseRecord>('expense_box');
    _incomeBox = Hive.box<IncomeRecord>('income_box');
    _settingsBox = Hive.box<FarmSettings>('settings_box');

    _loadFromHive();
  }

  void _loadFromHive() {
    cows = _cowsBox.values.toList();
    milkRecords = _milkBox.values.toList();
    healthRecords = _healthBox.values.toList();
    breedingRecords = _breedingBox.values.toList();
    expenses = _expenseBox.values.toList();
    incomes = _incomeBox.values.toList();

    if (_settingsBox.isNotEmpty) {
      settings = _settingsBox.getAt(0)!;
    }
    notifyListeners();
  }

  // --- Calculations ---
  String get todayStr => DateFormat('yyyy-MM-dd').format(DateTime.now());

  double get todayMilkTotal {
    return milkRecords
        .where((r) => r.date == todayStr)
        .fold(0.0, (sum, r) => sum + r.totalLiters);
  }

  double get avgFatToday {
    final todayList = milkRecords.where((r) => r.date == todayStr).toList();
    if (todayList.isEmpty) return 0.0;
    return todayList.fold(0.0, (sum, r) => sum + r.fat) / todayList.length;
  }

  double get totalIncomeSum => incomes.fold(0.0, (sum, i) => sum + i.amount);
  double get totalMilkIncome => milkRecords.fold(0.0, (sum, m) => sum + m.totalRevenue);
  double get netRevenueTotal => totalIncomeSum + totalMilkIncome;

  double get totalExpenseSum => expenses.fold(0.0, (sum, e) => sum + e.amount) +
      healthRecords.fold(0.0, (sum, h) => sum + h.cost);

  double get netProfit => netRevenueTotal - totalExpenseSum;

  // --- CRUD Operations ---
  void addCow(Cow cow) {
    _cowsBox.add(cow);
    cows.add(cow);
    notifyListeners();
  }

  void updateCow(Cow cow) {
    cow.save();
    notifyListeners();
  }

  void deleteCow(Cow cow) {
    cow.delete();
    cows.remove(cow);
    notifyListeners();
  }

  void addMilkRecord(MilkRecord record) {
    _milkBox.add(record);
    milkRecords.add(record);
    notifyListeners();
  }

  void updateMilkRecord(MilkRecord record) {
    record.save();
    notifyListeners();
  }

  void deleteMilkRecord(MilkRecord record) {
    record.delete();
    milkRecords.remove(record);
    notifyListeners();
  }

  void addHealthRecord(HealthRecord record) {
    _healthBox.add(record);
    healthRecords.add(record);
    notifyListeners();
  }

  void updateHealthRecord(HealthRecord record) {
    record.save();
    notifyListeners();
  }

  void deleteHealthRecord(HealthRecord record) {
    record.delete();
    healthRecords.remove(record);
    notifyListeners();
  }

  void addBreedingRecord(BreedingRecord record) {
    _breedingBox.add(record);
    breedingRecords.add(record);
    notifyListeners();
  }

  void updateBreedingRecord(BreedingRecord record) {
    record.save();
    notifyListeners();
  }

  void deleteBreedingRecord(BreedingRecord record) {
    record.delete();
    breedingRecords.remove(record);
    notifyListeners();
  }

  void addExpense(ExpenseRecord expense) {
    _expenseBox.add(expense);
    expenses.add(expense);
    notifyListeners();
  }

  void updateExpense(ExpenseRecord expense) {
    expense.save();
    notifyListeners();
  }

  void deleteExpense(ExpenseRecord expense) {
    expense.delete();
    expenses.remove(expense);
    notifyListeners();
  }

  void addIncome(IncomeRecord income) {
    _incomeBox.add(income);
    incomes.add(income);
    notifyListeners();
  }

  void updateIncome(IncomeRecord income) {
    income.save();
    notifyListeners();
  }

  void deleteIncome(IncomeRecord income) {
    income.delete();
    incomes.remove(income);
    notifyListeners();
  }

  void saveSettings(FarmSettings newSettings) {
    settings = newSettings;
    _settingsBox.clear();
    _settingsBox.add(newSettings);
    notifyListeners();
  }

  // --- JSON Export / Import Backup ---
  String exportBackupJson() {
    final map = {
      'cows': cows.map((c) => c.toJson()).toList(),
      'milkRecords': milkRecords.map((m) => m.toJson()).toList(),
      'healthRecords': healthRecords.map((h) => h.toJson()).toList(),
      'breedingRecords': breedingRecords.map((b) => b.toJson()).toList(),
      'expenses': expenses.map((e) => e.toJson()).toList(),
      'incomes': incomes.map((i) => i.toJson()).toList(),
      'settings': settings.toJson(),
    };
    return jsonEncode(map);
  }

  void importBackupJson(String jsonStr) {
    final map = jsonDecode(jsonStr);
    _cowsBox.clear();
    _milkBox.clear();
    _healthBox.clear();
    _breedingBox.clear();
    _expenseBox.clear();
    _incomeBox.clear();

    if (map['cows'] != null) {
      for (var item in map['cows']) {
        _cowsBox.add(Cow.fromJson(item));
      }
    }
    if (map['milkRecords'] != null) {
      for (var item in map['milkRecords']) {
        _milkBox.add(MilkRecord.fromJson(item));
      }
    }
    if (map['healthRecords'] != null) {
      for (var item in map['healthRecords']) {
        _healthBox.add(HealthRecord.fromJson(item));
      }
    }
    if (map['breedingRecords'] != null) {
      for (var item in map['breedingRecords']) {
        _breedingBox.add(BreedingRecord.fromJson(item));
      }
    }
    if (map['expenses'] != null) {
      for (var item in map['expenses']) {
        _expenseBox.add(ExpenseRecord.fromJson(item));
      }
    }
    if (map['incomes'] != null) {
      for (var item in map['incomes']) {
        _incomeBox.add(IncomeRecord.fromJson(item));
      }
    }
    if (map['settings'] != null) {
      saveSettings(FarmSettings.fromJson(map['settings']));
    }
    _loadFromHive();
  }
}
