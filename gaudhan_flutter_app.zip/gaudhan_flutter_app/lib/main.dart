import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'models/farm_models.dart';
import 'providers/farm_provider.dart';
import 'screens/home_dashboard_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Hive Offline Local Storage
  await Hive.initFlutter();
  
  // Register Adapters
  Hive.registerAdapter(CowAdapter());
  Hive.registerAdapter(MilkRecordAdapter());
  Hive.registerAdapter(HealthRecordAdapter());
  Hive.registerAdapter(BreedingRecordAdapter());
  Hive.registerAdapter(ExpenseRecordAdapter());
  Hive.registerAdapter(IncomeRecordAdapter());
  Hive.registerAdapter(FarmSettingsAdapter());

  // Open Boxes
  await Hive.openBox<Cow>('cows_box');
  await Hive.openBox<MilkRecord>('milk_box');
  await Hive.openBox<HealthRecord>('health_box');
  await Hive.openBox<BreedingRecord>('breeding_box');
  await Hive.openBox<ExpenseRecord>('expense_box');
  await Hive.openBox<IncomeRecord>('income_box');
  await Hive.openBox<FarmSettings>('settings_box');

  runApp(const GaudhanApp());
}

class GaudhanApp extends StatelessWidget {
  const GaudhanApp({super.key});

  @override
  Widget build(BuildContext context) {
    const primaryGreen = Color(0xFF1B5E20); // Deep Emerald Green
    const secondaryGreen = Color(0xFF2E7D32);

    return ChangeNotifierProvider(
      create: (_) => FarmProvider()..initData(),
      child: MaterialApp(
        title: 'ગૌધણ (Gaudhan Dairy Farm)',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: primaryGreen,
            primary: primaryGreen,
            secondary: secondaryGreen,
            surface: Colors.white,
            background: const Color(0xFFF4F8F4),
          ),
          scaffoldBackgroundColor: const Color(0xFFF4F8F4),
          appBarTheme: AppBarTheme(
            centerTitle: true,
            elevation: 0,
            backgroundColor: primaryGreen,
            foregroundColor: Colors.white,
            titleTextStyle: GoogleFonts.notoSansGujarati(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          textTheme: GoogleFonts.notoSansGujaratiTextTheme(
            Theme.of(context).textTheme,
          ),
          cardTheme: CardTheme(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: Colors.white,
          ),
        ),
        home: const HomeDashboardScreen(),
      ),
    );
  }
}
