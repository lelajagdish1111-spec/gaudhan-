# ગૌધણ (Gaudhan) - Offline Gujarati Dairy Farm & Cattle Management App

આ એક સંપૂર્ણ ૧૦૦% ઓફલાઇન ફ્લટર એપ્લિકેશન છે. આ એપ્લિકેશન ડેરી ફાર્મ વ્યવસ્થાપન, ગાય/ભેંસ ની માહિતી, દૂધ નોંધ, આરોગ્ય અને રસીકરણ, ગર્ભાધાન અને વાછરડું, ખર્ચ અને આવક હિસાબ માટે બનાવેલ છે.

## પ્રોજેક્ટ સેટઅપ અને રન કરવાનો ક્રમ:

1. **Flutter SDK ઇન્સ્ટોલ કરો**:
   ગૂગલની અધિકૃત વેબસાઇટ પરથી ફ્લટર ઇન્સ્ટોલ કરેલું હોવું જોઈએ.

2. **ડિપેન્ડન્સી ડાઉનલોડ કરો**:
   ```bash
   flutter pub get
   ```

3. **Hive Adaptor Build Runner ચલાવો** (Hive Database Code Gen):
   ```bash
   flutter pub run build_runner build --delete-conflicting-outputs
   ```

4. **એપ્લિકેશન રન કરો**:
   ```bash
   flutter run
   ```

## મુખ્ય ફીચર્સ:
- **Hive DB**: ૧૦૦% ઓફલાઇન ડેટા સંગ્રહ.
- **Gujarati UI**: સંપૂર્ણ ગુજરાતી ભાષા આધારિત સરળ ડિઝાઇન.
- **PDF & Excel Export**: રિપોર્ટ નિકાસ સુવિધા.
- **JSON Backup/Restore**: બેકઅપ ડાઉનલોડ અને રીસ્ટોર.
